import { Button } from '@/components/ui/button'
import { ArrowRight, BarChart2, Bell, Clock, Database } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="border-b">
        <div className="max-w-screen-xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">EquipMonitor</h1>
            <Button>Get Started</Button>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-screen-xl mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Crushing Efficiency:<br />Track Your Tonnage
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Maximize your crushing operations with accurate, real-time tonnage tracking.
            </p>
            <Button size="lg">
              Learn More
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20">
          <div className="max-w-screen-xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: Database,
                  title: 'Tonnage Tracking',
                  description: 'Accurately track the weight of materials crushed and processed in your operation.'
                },
                {
                  icon: BarChart2,
                  title: 'Production Reporting',
                  description: 'Generate detailed reports on your crushing performance, including tonnage and production rates.'
                },
                {
                  icon: Clock,
                  title: 'Real-time Monitoring',
                  description: 'Monitor your crushing process as it happens, providing instant insights.'
                },
                {
                  icon: Bell,
                  title: 'Alert System',
                  description: 'Receive notifications when production falls below expectations or equipment requires attention.'
                }
              ].map((feature, index) => (
                <div key={index} className="text-center">
                  <div className="bg-primary/5 w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}

