"use client"

import { useState, useEffect } from 'react'
import { Header } from "@/components/header"
import { NavBar } from "@/components/nav-bar"
import { ActiveEquipmentList } from "@/components/active-equipment-list"
import { EquipmentProduction } from "@/types/equipment-production"

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

// Mock function to fetch active equipment
const fetchActiveEquipment = async (): Promise<EquipmentProduction[]> => {
  // In a real application, this would be an API call
  return [
    { id: 'EQ-001', name: 'Crusher XC-2000', type: 'Crusher', dailyProduction: 240, weeklyProduction: 1680, monthlyProduction: 7200, yearToDateProduction: 43200, status: 'Active', manufacturingDate: '2021-05-15', chassisNumber: 'CHX2000-001', company: 'CrushTech Industries', model: 'XC-2000', maintenanceRecords: [] },
    { id: 'EQ-002', name: 'Loader L-400', type: 'Loader', dailyProduction: 180, weeklyProduction: 1260, monthlyProduction: 5400, yearToDateProduction: 32400, status: 'Active', manufacturingDate: '2020-11-30', chassisNumber: 'LDR400-002', company: 'HeavyLoad Machines', model: 'L-400', maintenanceRecords: [] },
    { id: 'EQ-003', name: 'Conveyor C-100', type: 'Conveyor', dailyProduction: 300, weeklyProduction: 2100, monthlyProduction: 9000, yearToDateProduction: 54000, status: 'Active', manufacturingDate: '2022-02-10', chassisNumber: 'CNV100-003', company: 'BeltWay Solutions', model: 'C-100', maintenanceRecords: [] },
  ]
}

export default function ActiveEquipmentPage() {
  const [activeEquipment, setActiveEquipment] = useState<EquipmentProduction[]>([])

  useEffect(() => {
    const loadActiveEquipment = async () => {
      const data = await fetchActiveEquipment()
      setActiveEquipment(data)
    }
    loadActiveEquipment()
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <h2 className="text-2xl font-semibold mb-6">Active Equipment</h2>
        <ActiveEquipmentList equipment={activeEquipment} />
      </main>
      <NavBar />
    </div>
  )
}

