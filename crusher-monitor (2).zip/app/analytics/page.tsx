import { Header } from '@/components/header'
import { NavBar } from '@/components/nav-bar'
import { EquipmentAnalyticsCard } from '@/components/equipment-analytics-card'
import { EquipmentAnalytics } from '@/types/analytics'

const mockAnalyticsData: EquipmentAnalytics[] = [
  {
    id: 'EQ-001',
    name: 'Crusher XC-2000',
    dailyProduction: [
      { date: '2023-06-01', tonnage: 240 },
      { date: '2023-06-02', tonnage: 238 },
      { date: '2023-06-03', tonnage: 245 },
      { date: '2023-06-04', tonnage: 250 },
      { date: '2023-06-05', tonnage: 235 },
    ],
    downtimeEvents: [
      { date: '2023-06-01', duration: 0.5 },
      { date: '2023-06-02', duration: 0.7 },
      { date: '2023-06-03', duration: 0.3 },
      { date: '2023-06-04', duration: 0.2 },
      { date: '2023-06-05', duration: 0.8 },
    ],
  },
  {
    id: 'EQ-002',
    name: 'Loader L-400',
    dailyProduction: [
      { date: '2023-06-01', tonnage: 180 },
      { date: '2023-06-02', tonnage: 175 },
      { date: '2023-06-03', tonnage: 185 },
      { date: '2023-06-04', tonnage: 178 },
      { date: '2023-06-05', tonnage: 182 },
    ],
    downtimeEvents: [
      { date: '2023-06-01', duration: 0.8 },
      { date: '2023-06-02', duration: 1.2 },
      { date: '2023-06-03', duration: 0.5 },
      { date: '2023-06-04', duration: 0.9 },
      { date: '2023-06-05', duration: 0.7 },
    ],
  },
]

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

export default function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <h2 className="text-2xl font-semibold mb-6">Equipment Analytics</h2>
        <div className="grid gap-6 md:grid-cols-2">
          {mockAnalyticsData.map((equipmentData) => (
            <EquipmentAnalyticsCard key={equipmentData.id} data={equipmentData} />
          ))}
        </div>
      </main>
      <NavBar />
    </div>
  )
}

