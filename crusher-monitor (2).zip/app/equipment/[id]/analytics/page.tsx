"use client"

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import { Header } from "@/components/header"
import { NavBar } from "@/components/nav-bar"
import { EquipmentAnalyticsCard } from "@/components/equipment-analytics-card"
import { Button } from "@/components/ui/button"
import { EquipmentAnalytics } from "@/types/analytics"
import { jsPDF } from "jspdf"
import "jspdf-autotable"
import { Chart, registerables } from 'chart.js'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'

Chart.register(...registerables)

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

// Mock function to fetch equipment analytics
const fetchEquipmentAnalytics = async (id: string): Promise<EquipmentAnalytics> => {
  // In a real application, this would be an API call
  return {
    id,
    name: `Equipment ${id}`,
    dailyProduction: [
      { date: '2023-06-01', tonnage: 240 },
      { date: '2023-06-02', tonnage: 238 },
      { date: '2023-06-03', tonnage: 245 },
      { date: '2023-06-04', tonnage: 250 },
      { date: '2023-06-05', tonnage: 235 },
    ],
    dieselConsumed: [
      { date: '2023-06-01', liters: 500 },
      { date: '2023-06-02', liters: 490 },
      { date: '2023-06-03', liters: 510 },
      { date: '2023-06-04', liters: 520 },
      { date: '2023-06-05', liters: 505 },
    ],
    downtimeEvents: [
      { date: '2023-06-01', duration: 0.5 },
      { date: '2023-06-02', duration: 0.7 },
      { date: '2023-06-03', duration: 0.3 },
      { date: '2023-06-04', duration: 0.2 },
      { date: '2023-06-05', duration: 0.8 },
    ],
    monthlyProduction: [
      { month: 'Jan', tonnage: 7200 },
      { month: 'Feb', tonnage: 6800 },
      { month: 'Mar', tonnage: 7500 },
      { month: 'Apr', tonnage: 7300 },
      { month: 'May', tonnage: 7600 },
      { month: 'Jun', tonnage: 7400 },
    ],
    operationalHours: [
      { day: 'Mon', hours: 22 },
      { day: 'Tue', hours: 23 },
      { day: 'Wed', hours: 21 },
      { day: 'Thu', hours: 22 },
      { day: 'Fri', hours: 23 },
      { day: 'Sat', hours: 20 },
      { day: 'Sun', hours: 18 },
    ],
  }
}

export default function EquipmentAnalyticsPage() {
  const params = useParams()
  const [analytics, setAnalytics] = useState<EquipmentAnalytics | null>(null)

  useEffect(() => {
    const loadAnalytics = async () => {
      if (params.id) {
        const data = await fetchEquipmentAnalytics(params.id as string)
        setAnalytics(data)
      }
    }
    loadAnalytics()
  }, [params.id])

  const generatePDF = () => {
    if (!analytics) return

    const doc = new jsPDF()

    // Add title
    doc.setFontSize(18)
    doc.text(`Analytics Report: ${analytics.name}`, 14, 22)

    // Function to add a chart to the PDF
    const addChartToPDF = (chart: Chart, title: string, yPos: number) => {
      doc.setFontSize(14)
      doc.text(title, 14, yPos)
      const chartImage = chart.toBase64Image()
      doc.addImage(chartImage, 'PNG', 10, yPos + 10, 190, 100)
    }

    // Diesel Consumed Chart
    const dieselChart = new Chart(document.createElement('canvas'), {
      type: 'line',
      data: {
        labels: analytics.dieselConsumed.map(d => d.date),
        datasets: [{
          label: 'Diesel Consumed (L)',
          data: analytics.dieselConsumed.map(d => d.liters),
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.1
        }]
      }
    })
    addChartToPDF(dieselChart, 'Diesel Consumed', 30)

    // Maintenance Events Chart
    const maintenanceChart = new Chart(document.createElement('canvas'), {
      type: 'bar',
      data: {
        labels: analytics.downtimeEvents.map(d => d.date),
        datasets: [{
          label: 'Downtime Duration (hours)',
          data: analytics.downtimeEvents.map(d => d.duration),
          backgroundColor: 'rgb(255, 99, 132)'
        }]
      }
    })
    addChartToPDF(maintenanceChart, 'Maintenance Events', 150)

    // Monthly Production Chart
    const productionChart = new Chart(document.createElement('canvas'), {
      type: 'bar',
      data: {
        labels: analytics.monthlyProduction.map(d => d.month),
        datasets: [{
          label: 'Monthly Production (tons)',
          data: analytics.monthlyProduction.map(d => d.tonnage),
          backgroundColor: 'rgb(54, 162, 235)'
        }]
      }
    })
    doc.addPage()
    addChartToPDF(productionChart, 'Monthly Production', 30)

    // Operational Hours Chart
    const operationalHoursChart = new Chart(document.createElement('canvas'), {
      type: 'bar',
      data: {
        labels: analytics.operationalHours.map(d => d.day),
        datasets: [{
          label: 'Operational Hours',
          data: analytics.operationalHours.map(d => d.hours),
          backgroundColor: 'rgb(255, 205, 86)'
        }]
      }
    })
    addChartToPDF(operationalHoursChart, 'Operational Hours (Last 7 Days)', 150)

    // Save the PDF
    doc.save(`${analytics.name}_analytics_report.pdf`)
  }

  if (!analytics) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Equipment Analytics: {analytics.name}</h2>
          <Button onClick={generatePDF}>Generate PDF Report</Button>
        </div>
        <EquipmentAnalyticsCard data={analytics} />
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-4">Monthly Production</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={analytics.monthlyProduction}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="tonnage" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-4">Operational Hours (Last 7 Days)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={analytics.operationalHours}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="hours" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </main>
      <NavBar />
    </div>
  )
}

