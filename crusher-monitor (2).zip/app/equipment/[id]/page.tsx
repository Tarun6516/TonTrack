"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Header } from "@/components/header"
import { NavBar } from "@/components/nav-bar"
import { EquipmentDetailTable } from "@/components/equipment-detail-table"
import { AddEntryModal } from "@/components/add-entry-modal"
import { DailyEquipmentData, Equipment } from "@/types/daily-equipment-data"
import { Button } from "@/components/ui/button"
import * as XLSX from 'xlsx'

// Mock data for equipment
const equipmentData: Equipment = {
  id: "EQ-001",
  name: "Crusher XC-2000",
  type: "Crusher",
}

// Mock data for daily equipment data
const initialDailyData: DailyEquipmentData[] = [
  { id: "1", date: "2023-06-01", production: 240, fuelConsumed: 500, maintenanceCost: 0, profit: 0, status: "Active" },
  { id: "2", date: "2023-06-02", production: 235, fuelConsumed: 490, maintenanceCost: 0, profit: 0, status: "Active" },
  { id: "3", date: "2023-06-03", production: 0, fuelConsumed: 0, maintenanceCost: 1500, profit: -1500, status: "Maintenance" },
  { id: "4", date: "2023-06-04", production: 250, fuelConsumed: 520, maintenanceCost: 0, profit: 0, status: "Active" },
  { id: "5", date: "2023-06-05", production: 245, fuelConsumed: 510, maintenanceCost: 0, profit: 0, status: "Active" },
]

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

export default function EquipmentDetailPage() {
  const params = useParams()
  const [dailyData, setDailyData] = useState(initialDailyData)
  const [settings, setSettings] = useState({
    ratePerTonne: 50,
    dieselPrice: 1.5,
    //calculationMethod: '(dailyProduction * tonnagePrice) - (fuelConsumed * dieselPrice) - maintenanceCost'
  })

  useEffect(() => {
    const savedSettings = localStorage.getItem('settings')
    if (savedSettings) {
      const parsedSettings = JSON.parse(savedSettings)
      setSettings(parsedSettings)
    
      // Recalculate profit for initial data
      const updatedDailyData = initialDailyData.map(entry => ({
        ...entry,
        profit: calculateProfit(entry, parsedSettings)
      }))
      setDailyData(updatedDailyData)
    }
  }, [])

  const handleAddEntry = (newEntry: Omit<DailyEquipmentData, 'id'>) => {
    const entry: DailyEquipmentData = {
      ...newEntry,
      id: (dailyData.length + 1).toString(),
      profit: calculateProfit(entry, settings)
    }
    setDailyData([...dailyData, entry])
  }

  const calculateProfit = (data: DailyEquipmentData, currentSettings: typeof settings) => {
    const { ratePerTonne, dieselPrice } = currentSettings
    const { production, fuelConsumed, maintenanceCost } = data
    return (production * Number(ratePerTonne)) - (fuelConsumed * Number(dieselPrice)) - maintenanceCost
  }

  const generateExcelReport = () => {
    const dataWithProfit = dailyData.map(day => ({
      ...day,
      profit: calculateProfit(day, settings)
    }))

    const weeklyProfit = dataWithProfit.reduce((sum, day) => sum + day.profit, 0)
    const monthlyProfit = weeklyProfit * 4 // Assuming 4 weeks in a month

    const worksheet = XLSX.utils.json_to_sheet(dataWithProfit)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, "Daily Report")

    // Add weekly and monthly profit
    XLSX.utils.sheet_add_aoa(worksheet, [
      ["Weekly Profit", weeklyProfit],
      ["Monthly Profit", monthlyProfit]
    ], { origin: -1 })
    
    // Generate a filename with the current date
    const date = new Date().toISOString().split('T')[0]
    const fileName = `${equipmentData.name}_Daily_Report_${date}.xlsx`
    
    // Convert the workbook to a binary string
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' })
    
    // Create a Blob from the buffer
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    
    // Create a download link and trigger the download
    const url = window.URL.createObjectURL(data)
    const link = document.createElement('a')
    link.href = url
    link.download = fileName
    link.click()
    
    // Clean up
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <h2 className="text-2xl font-semibold mb-2">{equipmentData.name}</h2>
        <p className="text-gray-500 mb-6">ID: {params.id} | Type: {equipmentData.type}</p>
        <div className="flex justify-between items-center mb-6">
          <AddEntryModal onAddEntry={handleAddEntry} />
          <Button onClick={generateExcelReport}>Generate Daily Excel Report</Button>
        </div>
        <EquipmentDetailTable data={dailyData} calculateProfit={calculateProfit} />
      </main>
      <NavBar />
    </div>
  )
}

