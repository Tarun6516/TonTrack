"use client"

import { useState } from 'react'
import { Header } from '@/components/header'
import { NavBar } from '@/components/nav-bar'
import { EquipmentTable } from '@/components/equipment-table'
import { AddEquipmentModal } from '@/components/add-equipment-modal'
import { EquipmentProduction } from '@/types/equipment-production'

const initialEquipmentData: EquipmentProduction[] = [
  {
    id: 'EQ-001',
    name: 'Crusher XC-2000',
    type: 'Crusher',
    dailyProduction: 240,
    weeklyProduction: 1680,
    monthlyProduction: 7200,
    yearToDateProduction: 43200,
    status: 'Active',
    manufacturingDate: '2021-05-15',
    chassisNumber: 'CHX2000-001',
    company: 'CrushTech Industries',
    model: 'XC-2000',
    maintenanceRecords: [
      { date: '2023-01-15', type: 'Routine', description: 'Oil change and general inspection', cost: 500 },
      { date: '2023-03-22', type: 'Repair', description: 'Replace worn crusher plates', cost: 2000 },
      { date: '2023-06-10', type: 'Routine', description: 'Lubrication and belt tensioning', cost: 300 },
    ],
  },
  {
    id: 'EQ-002',
    name: 'Loader L-400',
    type: 'Loader',
    dailyProduction: 180,
    weeklyProduction: 1260,
    monthlyProduction: 5400,
    yearToDateProduction: 32400,
    status: 'Active',
    manufacturingDate: '2020-11-30',
    chassisNumber: 'LDR400-002',
    company: 'HeavyLoad Machines',
    model: 'L-400',
    maintenanceRecords: [
      { date: '2023-02-05', type: 'Routine', description: 'Hydraulic fluid replacement', cost: 800 },
      { date: '2023-04-18', type: 'Repair', description: 'Repair hydraulic cylinder', cost: 1500 },
      { date: '2023-07-01', type: 'Overhaul', description: 'Major engine overhaul', cost: 5000 },
    ],
  },
  {
    id: 'EQ-003',
    name: 'Conveyor C-100',
    type: 'Conveyor',
    dailyProduction: 300,
    weeklyProduction: 2100,
    monthlyProduction: 9000,
    yearToDateProduction: 54000,
    status: 'Active',
    manufacturingDate: '2022-02-10',
    chassisNumber: 'CNV100-003',
    company: 'BeltWay Solutions',
    model: 'C-100',
    maintenanceRecords: [
      { date: '2023-03-10', type: 'Routine', description: 'Belt inspection and tensioning', cost: 200 },
      { date: '2023-05-25', type: 'Repair', description: 'Replace damaged rollers', cost: 600 },
      { date: '2023-08-15', type: 'Routine', description: 'Lubrication of bearings', cost: 150 },
    ],
  },
  {
    id: 'EQ-004',
    name: 'Screener S-500',
    type: 'Screener',
    dailyProduction: 220,
    weeklyProduction: 1540,
    monthlyProduction: 6600,
    yearToDateProduction: 39600,
    status: 'Maintenance',
    manufacturingDate: '2021-09-22',
    chassisNumber: 'SCR500-004',
    company: 'SiftMaster Corp',
    model: 'S-500',
    maintenanceRecords: [
      { date: '2023-01-30', type: 'Routine', description: 'Screen mesh inspection and cleaning', cost: 300 },
      { date: '2023-04-12', type: 'Repair', description: 'Replace worn screen mesh', cost: 1200 },
      { date: '2023-07-20', type: 'Overhaul', description: 'Overhaul vibration mechanism', cost: 3000 },
    ],
  },
  {
    id: 'EQ-005',
    name: 'Crusher XC-1500',
    type: 'Crusher',
    dailyProduction: 200,
    weeklyProduction: 1400,
    monthlyProduction: 6000,
    yearToDateProduction: 36000,
    status: 'Active',
    manufacturingDate: '2022-07-05',
    chassisNumber: 'CHX1500-005',
    company: 'CrushTech Industries',
    model: 'XC-1500',
    maintenanceRecords: [
      { date: '2023-02-20', type: 'Routine', description: 'Oil change and general inspection', cost: 450 },
      { date: '2023-05-08', type: 'Repair', description: 'Replace worn crusher liners', cost: 1800 },
      { date: '2023-08-01', type: 'Routine', description: 'Lubrication and adjustment', cost: 250 },
    ],
  },
]

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

export default function EquipmentsPage() {
  const [equipmentData, setEquipmentData] = useState(initialEquipmentData)

  const handleAddEquipment = (newEquipment: Omit<EquipmentProduction, 'id'>) => {
    const equipment: EquipmentProduction = {
      ...newEquipment,
      id: `EQ-${String(equipmentData.length + 1).padStart(3, '0')}`,
    }
    setEquipmentData([...equipmentData, equipment])
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Equipment Production</h2>
          <div className="space-x-2">
            <AddEquipmentModal onAddEquipment={handleAddEquipment} />
          </div>
        </div>
        <EquipmentTable data={equipmentData} />
      </main>
      <NavBar />
    </div>
  )
}

