"use client"

import { Suspense } from 'react'
import { useState } from 'react'
import { Header } from '@/components/header'
import { NavBar } from '@/components/nav-bar'
import { EquipmentCard } from '@/components/equipment-card'
import { Button } from '@/components/ui/button'
import { Filter } from 'lucide-react'
import { Equipment } from '@/types/equipment'

async function getEquipment(): Promise<Equipment[]> {
  // In a real app, this would be a database or API call
  return [
    {
      id: 'EQ-001',
      name: 'Crusher XC-2000',
      status: 'Active',
      productionRate: 250,
      operationTime: 4.5,
      nextService: '2h remaining'
    },
    {
      id: 'EQ-002',
      name: 'Loader L-400',
      status: 'Maintenance',
      productionRate: 180,
      operationTime: 8.5
    }
  ]
}

async function getStats(): Promise<{ activeEquipment: number; totalEquipment: number; alerts: number }> {
  // In a real app, this would be a database or API call
  return {
    activeEquipment: 24,
    totalEquipment: 30,
    alerts: 3
  }
}

export default async function DashboardPage() {
  const equipment = await getEquipment()
  const stats = await getStats()

  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">Equipment</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Suspense fallback={<div>Loading equipment...</div>}>
            {equipment.map((eq) => (
              <EquipmentCard key={eq.id} equipment={eq} />
            ))}
          </Suspense>
        </div>
      </main>
      <NavBar />
    </div>
  )
}

