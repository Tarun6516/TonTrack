"use client"

import { useState } from 'react'
import { useParams } from 'next/navigation'
import { Header } from '@/components/header'
import { NavBar } from '@/components/nav-bar'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { MonthlyEquipmentReport } from '@/components/monthly-equipment-report'
import { EquipmentProduction } from "@/types/equipment-production"

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

// Mock data for equipment
const equipmentData: EquipmentProduction[] = [
  { id: 'EQ-001', name: 'Crusher XC-2000', type: 'Crusher', dailyProduction: 240, weeklyProduction: 1680, monthlyProduction: 7200, yearToDateProduction: 43200, status: 'Active', manufacturingDate: '2021-05-15', chassisNumber: 'CHX2000-001', company: 'CrushTech Industries', model: 'XC-2000', maintenanceRecords: [] },
  { id: 'EQ-002', name: 'Loader L-400', type: 'Loader', dailyProduction: 180, weeklyProduction: 1260, monthlyProduction: 5400, yearToDateProduction: 32400, status: 'Active', manufacturingDate: '2020-11-30', chassisNumber: 'LDR400-002', company: 'HeavyLoad Machines', model: 'L-400', maintenanceRecords: [] },
  { id: 'EQ-003', name: 'Conveyor C-100', type: 'Conveyor', dailyProduction: 300, weeklyProduction: 2100, monthlyProduction: 9000, yearToDateProduction: 54000, status: 'Active', manufacturingDate: '2022-02-10', chassisNumber: 'CNV100-003', company: 'BeltWay Solutions', model: 'C-100', maintenanceRecords: [] },
]

export default function MonthlyReportPage() {
  const params = useParams()
  const month = params.month as string
  const currentYear = new Date().getFullYear()
  const [selectedEquipment, setSelectedEquipment] = useState<EquipmentProduction | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const handleEquipmentSelect = (equipment: EquipmentProduction) => {
    setSelectedEquipment(equipment)
    setIsDialogOpen(true)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <h2 className="text-2xl font-semibold mb-6">Equipment Reports for {month} {currentYear}</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {equipmentData.map((equipment) => (
            <Card key={equipment.id}>
              <CardHeader>
                <CardTitle>{equipment.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Type: {equipment.type}</p>
                <p>Monthly Production: {equipment.monthlyProduction} tons</p>
                <Button 
                  className="mt-4" 
                  onClick={() => handleEquipmentSelect(equipment)}
                >
                  View Reports
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Equipment Report</DialogTitle>
            </DialogHeader>
            {selectedEquipment && (
              <MonthlyEquipmentReport month={month} year={currentYear} equipment={selectedEquipment} />
            )}
          </DialogContent>
        </Dialog>
      </main>
      <NavBar />
    </div>
  )
}

