"use client"

import { useState } from 'react'
import { Header } from '@/components/header'
import { NavBar } from '@/components/nav-bar'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

const months = [
  'January', 'February', 'March', 'April', 'May', 'June', 
  'July', 'August', 'September', 'October', 'November', 'December'
]

export default function ReportManagementPage() {
  const currentYear = new Date().getFullYear()

  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <h2 className="text-2xl font-semibold mb-6">Report Management</h2>
        <Card>
          <CardHeader>
            <CardTitle>Equipment Calendar {currentYear}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
              {months.map((month) => (
                <Card key={month} className="bg-white">
                  <CardContent className="p-4">
                    <h3 className="text-lg font-semibold mb-2">{month}</h3>
                    <Link href={`/report-management/${month.toLowerCase()}`}>
                      <Button variant="outline" size="sm">
                        View Reports
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
      <NavBar />
    </div>
  )
}

