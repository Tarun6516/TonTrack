import { Header } from '@/components/header'
import { NavBar } from '@/components/nav-bar'
import { EquipmentReportCard } from '@/components/equipment-report-card'
import { EquipmentReport } from '@/types/report'

const mockReportData: EquipmentReport[] = [
  {
    id: 'EQ-001',
    name: 'Crusher XC-2000',
    monthlyProduction: [
      { month: 'Jan', tonnage: 7200 },
      { month: 'Feb', tonnage: 6800 },
      { month: 'Mar', tonnage: 7500 },
      { month: 'Apr', tonnage: 7300 },
      { month: 'May', tonnage: 7600 },
      { month: 'Jun', tonnage: 7400 },
    ],
    maintenanceEvents: [
      { name: 'Routine', value: 15 },
      { name: 'Repair', value: 5 },
      { name: 'Upgrade', value: 2 },
    ],
    operationalHours: [
      { day: 'Mon', hours: 22 },
      { day: 'Tue', hours: 23 },
      { day: 'Wed', hours: 21 },
      { day: 'Thu', hours: 22 },
      { day: 'Fri', hours: 23 },
      { day: 'Sat', hours: 20 },
      { day: 'Sun', hours: 18 },
    ],
  },
  {
    id: 'EQ-002',
    name: 'Loader L-400',
    monthlyProduction: [
      { month: 'Jan', tonnage: 5400 },
      { month: 'Feb', tonnage: 5200 },
      { month: 'Mar', tonnage: 5600 },
      { month: 'Apr', tonnage: 5300 },
      { month: 'May', tonnage: 5500 },
      { month: 'Jun', tonnage: 5400 },
    ],
    maintenanceEvents: [
      { name: 'Routine', value: 12 },
      { name: 'Repair', value: 8 },
      { name: 'Upgrade', value: 1 },
    ],
    operationalHours: [
      { day: 'Mon', hours: 20 },
      { day: 'Tue', hours: 21 },
      { day: 'Wed', hours: 19 },
      { day: 'Thu', hours: 20 },
      { day: 'Fri', hours: 21 },
      { day: 'Sat', hours: 18 },
      { day: 'Sun', hours: 16 },
    ],
  },
]

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

export default function ReportsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <h2 className="text-2xl font-semibold mb-6">Equipment Reports</h2>
        <div>
          {mockReportData.map((equipmentData) => (
            <EquipmentReportCard key={equipmentData.id} data={equipmentData} />
          ))}
        </div>
      </main>
      <NavBar />
    </div>
  )
}

