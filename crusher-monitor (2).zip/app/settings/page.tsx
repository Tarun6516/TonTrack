"use client"

import { useState, useEffect } from 'react'
import { Header } from "@/components/header"
import { NavBar } from "@/components/nav-bar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const stats = {
  activeEquipment: 24,
  totalEquipment: 30,
  alerts: 3
}

export default function SettingsPage() {
  const [ratePerTonne, setRatePerTonne] = useState('50')
  const [dieselPrice, setDieselPrice] = useState('1.5')

  useEffect(() => {
    const savedSettings = localStorage.getItem('settings')
    if (savedSettings) {
      const parsedSettings = JSON.parse(savedSettings)
      setRatePerTonne(parsedSettings.ratePerTonne)
      setDieselPrice(parsedSettings.dieselPrice)
    }
  }, [])

  const handleSave = () => {
    const settings = {
      ratePerTonne,
      dieselPrice,
    }
    localStorage.setItem('settings', JSON.stringify(settings))
    alert('Settings saved successfully!')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header stats={stats} />
      <main className="max-w-screen-xl mx-auto px-4 py-6 pb-20 md:pb-6">
        <h2 className="text-2xl font-semibold mb-6">Settings</h2>
        <Card>
          <CardHeader>
            <CardTitle>Pricing and Calculation Settings</CardTitle>
            <CardDescription>Adjust the pricing settings for profit calculations</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={(e) => { e.preventDefault(); handleSave(); }} className="space-y-4">
              <div>
                <Label htmlFor="ratePerTonne">Rate per Tonne ($/tonne)</Label>
                <Input
                  id="ratePerTonne"
                  type="number"
                  value={ratePerTonne}
                  onChange={(e) => setRatePerTonne(e.target.value)}
                  step="0.01"
                  min="0"
                />
              </div>
              <div>
                <Label htmlFor="dieselPrice">Diesel Price ($/liter)</Label>
                <Input
                  id="dieselPrice"
                  type="number"
                  value={dieselPrice}
                  onChange={(e) => setDieselPrice(e.target.value)}
                  step="0.01"
                  min="0"
                />
              </div>
              <Button type="submit">Save Settings</Button>
            </form>
          </CardContent>
        </Card>
      </main>
      <NavBar />
    </div>
  )
}

