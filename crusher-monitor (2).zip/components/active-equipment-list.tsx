import Link from 'next/link'
import { EquipmentProduction } from "@/types/equipment-production"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface ActiveEquipmentListProps {
  equipment: EquipmentProduction[]
}

export function ActiveEquipmentList({ equipment }: ActiveEquipmentListProps) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {equipment.map((item) => (
        <Link href={`/equipment/${item.id}`} key={item.id}>
          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader>
              <CardTitle>{item.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p><strong>ID:</strong> {item.id}</p>
              <p><strong>Type:</strong> {item.type}</p>
              <p><strong>Daily Production:</strong> {item.dailyProduction} tons</p>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}

