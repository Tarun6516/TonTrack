"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DailyEquipmentData } from "@/types/daily-equipment-data"

interface AddEntryModalProps {
  onAddEntry: (entry: Omit<DailyEquipmentData, 'id'>) => void
}

export function AddEntryModal({ onAddEntry }: AddEntryModalProps) {
  const [open, setOpen] = useState(false)
  const [date, setDate] = useState("")
  const [production, setProduction] = useState("")
  const [fuelConsumed, setFuelConsumed] = useState("")
  const [maintenanceCost, setMaintenanceCost] = useState("")
  const [status, setStatus] = useState<DailyEquipmentData['status']>("Active")
  const [ratePerTonne, setRatePerTonne] = useState("50")
  const [dieselPrice, setDieselPrice] = useState("1.5")

  useEffect(() => {
    const savedSettings = localStorage.getItem('settings')
    if (savedSettings) {
      const parsedSettings = JSON.parse(savedSettings)
      setRatePerTonne(parsedSettings.ratePerTonne)
      setDieselPrice(parsedSettings.dieselPrice)
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const productionValue = Number(production)
    const fuelConsumedValue = Number(fuelConsumed)
    const maintenanceCostValue = Number(maintenanceCost)
    const profit = calculateProfit(productionValue, fuelConsumedValue, maintenanceCostValue)
    onAddEntry({
      date,
      production: productionValue,
      fuelConsumed: fuelConsumedValue,
      maintenanceCost: maintenanceCostValue,
      profit,
      status,
    })
    setOpen(false)
    // Reset form
    setDate("")
    setProduction("")
    setFuelConsumed("")
    setMaintenanceCost("")
    setStatus("Active")
  }

  const calculateProfit = (production: number, fuelConsumed: number, maintenanceCost: number) => {
    return (production * Number(ratePerTonne)) - (fuelConsumed * Number(dieselPrice)) - maintenanceCost
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="fixed bottom-20 right-4 md:bottom-4">Add New Entry</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Entry</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="date">Date</Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="production">Production (tons)</Label>
            <Input
              id="production"
              type="number"
              value={production}
              onChange={(e) => setProduction(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="fuelConsumed">Fuel Consumed (L)</Label>
            <Input
              id="fuelConsumed"
              type="number"
              value={fuelConsumed}
              onChange={(e) => setFuelConsumed(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="maintenanceCost">Maintenance Cost ($)</Label>
            <Input
              id="maintenanceCost"
              type="number"
              value={maintenanceCost}
              onChange={(e) => setMaintenanceCost(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="status">Status</Label>
            <Select value={status} onValueChange={(value: DailyEquipmentData['status']) => setStatus(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Maintenance">Maintenance</SelectItem>
                <SelectItem value="Inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit">Add Entry</Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}

