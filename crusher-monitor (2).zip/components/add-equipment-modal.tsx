"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { EquipmentProduction } from "@/types/equipment-production"

interface AddEquipmentModalProps {
  onAddEquipment: (equipment: Omit<EquipmentProduction, 'id'>) => void
}

export function AddEquipmentModal({ onAddEquipment }: AddEquipmentModalProps) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState("")
  const [type, setType] = useState("")
  const [dailyProduction, setDailyProduction] = useState("")
  const [status, setStatus] = useState<EquipmentProduction['status']>("Active")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onAddEquipment({
      name,
      type,
      dailyProduction: Number(dailyProduction),
      weeklyProduction: Number(dailyProduction) * 7,
      monthlyProduction: Number(dailyProduction) * 30,
      yearToDateProduction: Number(dailyProduction) * 365,
      status,
    })
    setOpen(false)
    // Reset form
    setName("")
    setType("")
    setDailyProduction("")
    setStatus("Active")
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Add New Equipment</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Equipment</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Equipment Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="type">Equipment Type</Label>
            <Input
              id="type"
              value={type}
              onChange={(e) => setType(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="dailyProduction">Daily Production (tons)</Label>
            <Input
              id="dailyProduction"
              type="number"
              value={dailyProduction}
              onChange={(e) => setDailyProduction(e.target.value)}
              required
            />
          </div>
          <div>
            <Label htmlFor="status">Status</Label>
            <Select value={status} onValueChange={(value: EquipmentProduction['status']) => setStatus(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Maintenance">Maintenance</SelectItem>
                <SelectItem value="Inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit">Add Equipment</Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}

