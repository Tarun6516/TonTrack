import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { EquipmentAnalytics } from "@/types/analytics"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

interface EquipmentAnalyticsCardProps {
  data: EquipmentAnalytics
}

export function EquipmentAnalyticsCard({ data }: EquipmentAnalyticsCardProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{data.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-medium mb-2">Daily Production</h4>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={data.dailyProduction}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="tonnage" stroke="#8884d8" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div>
            <h4 className="text-sm font-medium mb-2">Diesel Consumed</h4>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={data.dieselConsumed}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="liters" stroke="#82ca9d" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div>
            <h4 className="text-sm font-medium mb-2">Downtime Events</h4>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={data.downtimeEvents}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="duration" stroke="#ffc658" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

