import Link from 'next/link'
import { Equipment } from '@/types/equipment'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface EquipmentCardProps {
  equipment: Equipment
}

export function EquipmentCard({ equipment }: { equipment: Equipment }) {
  const getStatusColor = (status: Equipment['status']) => {
    switch (status) {
      case 'Active':
        return 'bg-green-500'
      case 'Maintenance':
        return 'bg-yellow-500'
      default:
        return 'bg-gray-500'
    }
  }

  return (
    <Link href={`/equipment/${equipment.id}`}>
      <Card className="hover:shadow-lg transition-shadow duration-200">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-medium">{equipment.name}</CardTitle>
            <Badge variant="secondary" className={getStatusColor(equipment.status)}>
              {equipment.status}
            </Badge>
          </div>
          <div className="text-sm text-gray-500">ID: {equipment.id}</div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Production Rate</span>
                <span>{equipment.productionRate} tons/hr</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>
            {equipment.operationTime && (
              <div className="text-sm">
                <span className="font-medium">Operation Time:</span> {equipment.operationTime} hours
              </div>
            )}
            {equipment.nextService && (
              <div className="text-sm">
                <span className="font-medium">Next Service:</span> {equipment.nextService}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

