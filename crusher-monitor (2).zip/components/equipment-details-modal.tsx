"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { EquipmentProduction } from "@/types/equipment-production"
import { MaintenanceReportModal } from "./maintenance-report-modal"

interface EquipmentDetailsModalProps {
  equipment: EquipmentProduction
}

export function EquipmentDetailsModal({ equipment }: EquipmentDetailsModalProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <Button variant="ghost" onClick={() => setIsOpen(true)}>View details</Button>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{equipment.name} Details</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 items-center gap-4">
              <span className="font-medium">ID:</span>
              <span>{equipment.id}</span>
            </div>
            <div className="grid grid-cols-2 items-center gap-4">
              <span className="font-medium">Type:</span>
              <span>{equipment.type}</span>
            </div>
            <div className="grid grid-cols-2 items-center gap-4">
              <span className="font-medium">Company:</span>
              <span>{equipment.company}</span>
            </div>
            <div className="grid grid-cols-2 items-center gap-4">
              <span className="font-medium">Model:</span>
              <span>{equipment.model}</span>
            </div>
            <div className="grid grid-cols-2 items-center gap-4">
              <span className="font-medium">Manufacturing Date:</span>
              <span>{new Date(equipment.manufacturingDate).toLocaleDateString()}</span>
            </div>
            <div className="grid grid-cols-2 items-center gap-4">
              <span className="font-medium">Chassis Number:</span>
              <span>{equipment.chassisNumber}</span>
            </div>
            <div className="mt-4">
              <MaintenanceReportModal 
                equipmentName={equipment.name}
                maintenanceRecords={equipment.maintenanceRecords}
              />
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

