"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { EquipmentReport } from "@/types/report"
import { BarChart, Bar, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { Button } from "@/components/ui/button"
import { jsPDF } from "jspdf"
import "jspdf-autotable"

interface EquipmentReportCardProps {
  data: EquipmentReport
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export function EquipmentReportCard({ data }: EquipmentReportCardProps) {
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false)

  const generatePDF = () => {
    setIsGeneratingPDF(true)
    const doc = new jsPDF()

    // Add title
    doc.setFontSize(18)
    doc.text(`Equipment Report: ${data.name}`, 14, 22)

    // Add monthly production data
    doc.setFontSize(14)
    doc.text("Monthly Production", 14, 32)
    doc.autoTable({
      startY: 40,
      head: [["Month", "Tonnage"]],
      body: data.monthlyProduction.map(item => [item.month, item.tonnage]),
    })

    // Add maintenance events data
    const finalY = (doc as any).lastAutoTable.finalY || 40
    doc.setFontSize(14)
    doc.text("Maintenance Events", 14, finalY + 10)
    doc.autoTable({
      startY: finalY + 18,
      head: [["Event", "Count"]],
      body: data.maintenanceEvents.map(item => [item.name, item.value]),
    })

    // Add operational hours data
    const finalY2 = (doc as any).lastAutoTable.finalY || 40
    doc.setFontSize(14)
    doc.text("Operational Hours (Last 7 Days)", 14, finalY2 + 10)
    doc.autoTable({
      startY: finalY2 + 18,
      head: [["Day", "Hours"]],
      body: data.operationalHours.map(item => [item.day, item.hours]),
    })

    // Save the PDF
    doc.save(`${data.name}_report.pdf`)
    setIsGeneratingPDF(false)
  }

  return (
    <Card className="w-full mb-6">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle>{data.name}</CardTitle>
        <Button onClick={generatePDF} disabled={isGeneratingPDF}>
          {isGeneratingPDF ? "Generating PDF..." : "Generate PDF Report"}
        </Button>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <h4 className="text-sm font-medium mb-2">Monthly Production</h4>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={data.monthlyProduction}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="tonnage" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div>
            <h4 className="text-sm font-medium mb-2">Maintenance Events</h4>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={data.maintenanceEvents}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {data.maintenanceEvents.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div>
            <h4 className="text-sm font-medium mb-2">Operational Hours (Last 7 Days)</h4>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={data.operationalHours}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="hours" fill="#ffc658" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

