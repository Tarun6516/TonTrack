import Link from 'next/link'
import { Bell } from 'lucide-react'
import { DashboardStats } from '@/types/equipment'

interface HeaderProps {
  stats: DashboardStats
}

export function Header({ stats }: { stats: DashboardStats }) {
  return (
    <header className="bg-white border-b">
      <div className="max-w-screen-xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold">EquipMonitor</h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-8">
              <Link href="/active-equipment" className="hover:underline">
                <div>
                  <div className="text-sm text-gray-500">Active Equipment</div>
                  <div className="text-xl font-semibold">{stats.activeEquipment}/{stats.totalEquipment}</div>
                </div>
              </Link>
              <div>
                <div className="text-sm text-gray-500">Alerts</div>
                <div className="text-xl font-semibold">{stats.alerts}</div>
              </div>
            </div>
            <Bell className="h-6 w-6 text-gray-600" />
          </div>
        </div>
      </div>
    </header>
  )
}

