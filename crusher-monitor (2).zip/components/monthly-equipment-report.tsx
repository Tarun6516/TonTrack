"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { EquipmentProduction } from "@/types/equipment-production"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface MonthlyEquipmentReportProps {
  month: string
  year: number
  equipment: EquipmentProduction
}

export function MonthlyEquipmentReport({ month, year, equipment }: MonthlyEquipmentReportProps) {
  const [activeTab, setActiveTab] = useState("daily")
  const [ratePerTonne, setRatePerTonne] = useState(50)
  const [dieselPrice, setDieselPrice] = useState(1.5)

  useEffect(() => {
    const savedSettings = localStorage.getItem('settings')
    if (savedSettings) {
      const parsedSettings = JSON.parse(savedSettings)
      setRatePerTonne(Number(parsedSettings.ratePerTonne))
      setDieselPrice(Number(parsedSettings.dieselPrice))
    }
  }, [])

  const generateReport = (type: string) => {
    // In a real application, this would generate the report
    console.log(`Generating ${type} report for ${equipment.name}`)
    // Simulate report generation delay
    setTimeout(() => {
      alert(`${type} report generated for ${equipment.name}`)
    }, 1000)
  }

  const downloadReport = (type: string) => {
    // In a real application, this would download the report
    console.log(`Downloading ${type} report for ${equipment.name}`)
    // Simulate download delay
    setTimeout(() => {
      alert(`${type} report downloaded for ${equipment.name}`)
    }, 1000)
  }

  // Mock data for the graph
  const graphData = [
    { date: '2023-06-01', production: 240, fuelConsumed: 500, maintenanceCost: 100 },
    { date: '2023-06-02', production: 250, fuelConsumed: 520, maintenanceCost: 80 },
    { date: '2023-06-03', production: 230, fuelConsumed: 480, maintenanceCost: 120 },
    { date: '2023-06-04', production: 260, fuelConsumed: 540, maintenanceCost: 90 },
    { date: '2023-06-05', production: 245, fuelConsumed: 510, maintenanceCost: 110 },
    { date: '2023-06-06', production: 255, fuelConsumed: 530, maintenanceCost: 95 },
    { date: '2023-06-07', production: 270, fuelConsumed: 560, maintenanceCost: 85 },
  ].map(day => ({
    ...day,
    profit: (day.production * ratePerTonne) - (day.fuelConsumed * dieselPrice) - day.maintenanceCost
  }))

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold">{equipment.name} - {month} {year} Report</h3>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="daily">Daily Report</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance Report</TabsTrigger>
          <TabsTrigger value="analytics">Analytics Report</TabsTrigger>
          <TabsTrigger value="graph">Graph</TabsTrigger>
        </TabsList>
        
        <TabsContent value="daily">
          <Card>
            <CardHeader>
              <CardTitle>Daily Report</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Daily production data and statistics would be displayed here.</p>
              <Button onClick={() => downloadReport('Daily')} className="mt-4">Download Daily Report</Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="maintenance">
          <Card>
            <CardHeader>
              <CardTitle>Maintenance Report</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Maintenance records and upcoming schedules would be displayed here.</p>
              <Button onClick={() => downloadReport('Maintenance')} className="mt-4">Download Maintenance Report</Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Analytics Report</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Detailed analytics and performance metrics would be displayed here.</p>
              <Button onClick={() => downloadReport('Analytics')} className="mt-4">Download Analytics Report</Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="graph">
          <Card>
            <CardHeader>
              <CardTitle>Production and Profit Graph</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={graphData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip 
                    labelFormatter={(value) => new Date(value).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                  />
                  <Bar yAxisId="left" dataKey="production" fill="#8884d8" name="Daily Production" />
                  <Bar yAxisId="right" dataKey="profit" fill="#82ca9d" name="Daily Profit" />
                </BarChart>
              </ResponsiveContainer>
              <Button onClick={() => downloadReport('Graph')} className="mt-4">Download Graph</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

