'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, BarChart2, FileText, Settings, Truck, FileSpreadsheet } from 'lucide-react'

export function NavBar() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t h-16 px-4 flex items-center justify-between md:relative md:border-t-0">
      <div className="flex items-center justify-between w-full max-w-screen-xl mx-auto">
        <Link href="/" className={`flex flex-col items-center text-sm ${pathname === '/' ? 'text-primary' : 'text-gray-500'}`}>
          <Home className="h-6 w-6" />
          <span>Home</span>
        </Link>
        <Link href="/equipments" className={`flex flex-col items-center text-sm ${pathname === '/equipments' ? 'text-primary' : 'text-gray-500'}`}>
          <Truck className="h-6 w-6" />
          <span>Equipments</span>
        </Link>
        <Link href="/analytics" className={`flex flex-col items-center text-sm ${pathname === '/analytics' ? 'text-primary' : 'text-gray-500'}`}>
          <BarChart2 className="h-6 w-6" />
          <span>Analytics</span>
        </Link>
        <Link href="/reports" className={`flex flex-col items-center text-sm ${pathname === '/reports' ? 'text-primary' : 'text-gray-500'}`}>
          <FileText className="h-6 w-6" />
          <span>Reports</span>
        </Link>
        <Link href="/report-management" className={`flex flex-col items-center text-sm ${pathname === '/report-management' ? 'text-primary' : 'text-gray-500'}`}>
          <FileSpreadsheet className="h-6 w-6" />
          <span>Report Mgmt</span>
        </Link>
        <Link href="/settings" className={`flex flex-col items-center text-sm ${pathname === '/settings' ? 'text-primary' : 'text-gray-500'}`}>
          <Settings className="h-6 w-6" />
          <span>Settings</span>
        </Link>
      </div>
    </nav>
  )
}

