"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ReportData } from '@/types/report'

interface ReportUploaderProps {
  onUpload: (data: ReportData) => void
}

export function ReportUploader({ onUpload }: ReportUploaderProps) {
  const [file, setFile] = useState<File | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0])
    }
  }

  const handleUpload = async () => {
    if (file) {
      // In a real application, you would parse the file here
      // For this example, we'll just simulate parsing with a timeout
      setTimeout(() => {
        const simulatedData: ReportData = {
          title: 'Uploaded Report',
          date: new Date().toISOString().split('T')[0],
          equipmentId: 'EQ-001',
          description: 'This is a simulated uploaded report',
          productionData: 'Simulated production data',
          maintenanceNotes: 'Simulated maintenance notes',
        }
        onUpload(simulatedData)
      }, 1000)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="file-upload">Upload Report File</Label>
        <Input
          id="file-upload"
          type="file"
          onChange={handleFileChange}
          accept=".csv,.xlsx,.xls"
        />
      </div>
      <Button onClick={handleUpload} disabled={!file}>
        Upload and Parse
      </Button>
    </div>
  )
}

