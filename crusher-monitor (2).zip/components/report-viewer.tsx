interface ReportViewerProps {
  report: string | null
}

export function ReportViewer({ report }: ReportViewerProps) {
  if (!report) {
    return <div>No report generated yet. Please enter or upload report data first.</div>
  }

  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="text-lg font-semibold mb-2">Generated Report</h3>
      <pre className="whitespace-pre-wrap">{report}</pre>
    </div>
  )
}

