export interface EquipmentAnalytics {
  id: string;
  name: string;
  dailyProduction: { date: string; tonnage: number }[];
  dieselConsumed: { date: string; liters: number }[];
  downtimeEvents: { date: string; duration: number }[];
  monthlyProduction: { month: string; tonnage: number }[];
  operationalHours: { day: string; hours: number }[];
}

