export interface DailyEquipmentData {
  id: string;
  date: string;
  production: number;
  fuelConsumed: number;
  maintenanceCost: number;
  profit: number;
  status: 'Active' | 'Maintenance' | 'Inactive';
}

export interface Equipment {
  id: string;
  name: string;
  type: string;
}

