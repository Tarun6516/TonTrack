export interface MaintenanceRecord {
  date: string;
  type: 'Routine' | 'Repair' | 'Overhaul';
  description: string;
  cost: number;
}

export interface EquipmentProduction {
  id: string;
  name: string;
  type: string;
  dailyProduction: number;
  weeklyProduction: number;
  monthlyProduction: number;
  yearToDateProduction: number;
  status: 'Active' | 'Maintenance' | 'Inactive';
  manufacturingDate: string;
  chassisNumber: string;
  company: string;
  model: string;
  maintenanceRecords: MaintenanceRecord[];
}

