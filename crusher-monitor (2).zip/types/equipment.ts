export interface Equipment {
  id: string;
  name: string;
  status: 'Active' | 'Maintenance' | 'Inactive';
  productionRate: number;
  operationTime?: number;
  nextService?: string;
}

export interface DashboardStats {
  activeEquipment: number;
  totalEquipment: number;
  alerts: number;
}

