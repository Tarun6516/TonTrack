export interface EquipmentReport {
  id: string;
  name: string;
  monthlyProduction: { month: string; tonnage: number }[];
  maintenanceEvents: { name: string; value: number }[];
  operationalHours: { day: string; hours: number }[];
}

export interface ReportData {
  title: string;
  date: string;
  equipmentId: string;
  description: string;
  productionData: string;
  maintenanceNotes: string;
}

